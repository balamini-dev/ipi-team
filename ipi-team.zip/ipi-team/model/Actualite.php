<?php 
require '../../config/MyPDO.php';


class Actualite{
	private $id;
	private $titre;
	private $description;
	private $date;
	private $id_utilisateur_fk;
	private $nom_utilisateur_fk;
	private $prenom_utilisateur_fk;

	public function __construct($id = null) {

		if (isset($id)) {
			$oMyPdo = new MyPDO();
			$sql = "SELECT * FROM actualites WHERE id =".$id;
			$oMyPdoStmt = $oMyPdo->prepare($sql);
			$oMyPdoStmt->execute();
			$result = $oMyPdoStmt->fetch();

			$this->id = $result[0];
			$this->titre = $result[1];
			$this->description = $result[2];
			$this->date = $result[3];
			$this->id_utilisateur_fk = $result[4];

			$sql = "SELECT id, nom, prenom FROM utilisateur WHERE id =".$this->id_utilisateur_fk;
			$oMyPdoStmt = $oMyPdo->prepare($sql);
			$oMyPdoStmt->execute();
			$result = $oMyPdoStmt->fetch();
			$this->nom_utilisateur_fk = $result[1];
			$this->prenom_utilisateur_fk = $result[2];
		}
	}
	
	public function getId() {
		return $this->id;
	}

	public function getTitre() {
		return $this->titre;
	}

	public function getDescription() {
		return $this->description;
	}

	public function getDate() {
		return $this->date;
	}

	public function getIdUtilisateur() {
		return $this->id_utilisateur_fk;
	}

	public function getNomUtilisateur() {
		return $this->nom_utilisateur_fk;
	}

	public function getPrenomUtilisateur() {
		return $this->prenom_utilisateur_fk;
	}

////////////////////////////////////////////////////

	public function setId($id) {
		$this->id = $id;
	}

	public function setTitre($titre) {
		$this->titre = $titre;
	}

	public function setDescription($description) {
		$this->description = $description;
	}

	public function setDate($date) {
		$this->date = $date;
	}

	public function setIdUtilisateur($id) {
		$this->id_utilisateur_fk = $id;
	}

	public function createActualite() {
		$oMyPdo = new MyPDO();
		$sSql = "INSERT INTO actualites (titre, description, date, id_utilisateur_fk) VALUES (?, ?, ?, ?)";
		$oMyPdoStmt = $oMyPdo->prepare($sSql);
		$oMyPdoStmt->bindParam(1, $this->titre);
		$oMyPdoStmt->bindParam(2, $this->description);
		$oMyPdoStmt->bindParam(3, $this->date);
		$oMyPdoStmt->bindParam(4, $this->id_utilisateur_fk);
		return $oMyPdoStmt->execute();
	}

	public static function readAll() {
		$oPdo = new MyPDO();
		$sSql = "SELECT * FROM actualites";
		$oPdoStmt = $oPdo->query($sSql);
		$actualites = $oPdoStmt->fetchAll(PDO::FETCH_CLASS, __CLASS__);	
		return $actualites;	
	}
}




 ?>