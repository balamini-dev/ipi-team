<?php
require '../../config/MyPDO.php';

class Evenement{
	private $id;
	private $titre;
	private $lieu;
	private $date;
	private $descriptif;
	private $type;
	private $id_utilisateur_fk;
	private $nom_utilisateur_fk;
	private $prenom_utilisateur_fk;


	public function __construct($id = null) {

		if (isset($id)) {
			$oMyPdo = new MyPDO();
			$sql = "SELECT * FROM evenement WHERE id =".$id;
			$oMyPdoStmt = $oMyPdo->prepare($sql);
			$oMyPdoStmt->execute();
			$result = $oMyPdoStmt->fetch();

			$this->id = $result[0];
			$this->titre = $result[1];
			$this->lieu = $result[2];
			$this->date = $result[3];
			$this->descriptif = $result[4];
			$this->type = $result[5];
			$this->id_utilisateur_fk = $result[6];

			$sql = "SELECT id, nom, prenom FROM utilisateur WHERE id =".$this->id_utilisateur_fk;
			$oMyPdoStmt = $oMyPdo->prepare($sql);
			$oMyPdoStmt->execute();
			$result = $oMyPdoStmt->fetch();
			$this->nom_utilisateur_fk = $result[1];
			$this->prenom_utilisateur_fk = $result[2];
		}
	}
	
	public function getId() {
		return $this->id;
	}

	public function getTitre() {
		return $this->titre;
	}

	public function getLieu() {
		return $this->lieu;
	}

	public function getDate() {
		return $this->date;
	}

	public function getDescriptif() {
		return $this->descriptif;
	}

	public function getType() {
		return $this->type;
	}

	public function getIdUtilisateur() {
		return $this->id_utilisateur_fk;
	}

	public function getNomUtilisateur() {
		return $this->nom_utilisateur_fk;
	}

	public function getPrenomUtilisateur() {
		return $this->prenom_utilisateur_fk;
	}

////////////////////////////////////////////////////

	public function setId($id) {
		$this->id = $id;
	}

	public function setTitre($titre) {
		$this->titre = $titre;
	}

	public function setLieu($lieu) {
		$this->lieu = $lieu;
	}

	public function setDate($date) {
		$this->date = $date;
	}

	public function setDescriptif($descriptif) {
		$this->descriptif = $descriptif;
	}

	public function setType($type) {
		$this->type = $type;
	}

	public function setIdUtilisateur($id_utilisateur_fk) {
		$this->id_utilisateur_fk = $id_utilisateur_fk;
	}

	public function createEvenement() {
		$oMyPdo = new MyPDO();
		$sSql = "INSERT INTO evenement (titre, lieu, date, descriptif, type, id_utilisateur_fk) VALUES (?, ?, ?, ?, ?, ?)";
		$oMyPdoStmt = $oMyPdo->prepare($sSql);
		$oMyPdoStmt->bindParam(1, $this->titre);
		$oMyPdoStmt->bindParam(2, $this->lieu);
		$oMyPdoStmt->bindParam(3, $this->date);
		$oMyPdoStmt->bindParam(4, $this->descriptif);
		$oMyPdoStmt->bindParam(5, $this->type);
		$oMyPdoStmt->bindParam(6, $this->id_utilisateur_fk);
		return $oMyPdoStmt->execute();
	}

	public static function readAll() {
		$oPdo = new MyPDO();
		$sSql = "SELECT * FROM evenement";
		$oPdoStmt = $oPdo->query($sSql);
		$evenements = $oPdoStmt->fetchAll(PDO::FETCH_CLASS, __CLASS__);	
		return $evenements;	
	}
}



  ?>