<?php
require '../../config/MyPDO.php';

class Utilisateur{
	private $id;
	private $nom;
	private $prenom;
	private $tel;
	private $mail;
	private $adresseNum;
	private $adresseVoie;
	private $adresseCp;
	private $adresseVille;
	private $carteId;
	private $login;
	private $mot_passe;
	private $id_profil;

	public function __construct($id = null) {

		if (isset($id)) {
			$oMyPdo = new MyPDO();
			$sql = "SELECT * FROM utilisateur WHERE id =".$id;
			$oMyPdoStmt = $oMyPdo->prepare($sql);
			$oMyPdoStmt->execute();
			$result = $oMyPdoStmt->fetch();

			$this->id = $result[0];
			$this->nom = $result[1];
			$this->prenom = $result[2];
			$this->adresseNum = $result[3];
			$this->adresseVoie = $result[4];
			$this->adresseCp = $result[5];
			$this->adresseVille = $result[6];
			$this->mail = $result[7];
			$this->tel = $result[8];
			$this->carteId = $result[9];

			$sql = "SELECT * FROM lier WHERE id_utilisateur_fk =".$id;
			$oMyPdoStmt = $oMyPdo->prepare($sql);
			$oMyPdoStmt->execute();
			$result = $oMyPdoStmt->fetch();
			$this->id_profil=$result[1];
			$this->login=$result[2];
			$this->mot_passe=$result[3];

		}

	}
	
	public function getId() {
		return $this->id;
	}

	public function getNom() {
		return $this->nom;
	}

	public function getPrenom() {
		return $this->prenom;
	}

	public function getTel() {
		return $this->tel;
	}

	public function getMail() {
		return $this->mail;
	}

	public function getAdresseNum() {
		return $this->adresseNum;
	}

	public function getAdresseVoie() {
		return $this->adresseVoie;
	}
	public function getadresseCp() {
		return $this->adresseCp;
	}

	public function getAdresseVille() {
		return $this->adresseVille;
	}

	public function getCarteId() {
		return $this->carteId;
	}

	public function getLogin() {
		return $this->login;
	}

	public function getMdp() {
		return $this->mot_passe;
	}

	public function getIdProfil() {
		return $this->id_profil;
	}

////////////////////////////////////////////////////

	public function setId($id) {
		$this->id = $id;
	}

	public function setNom($nom) {
		$this->nom = $nom;
	}

	public function setPrenom($prenom) {
		$this->prenom = $prenom;
	}

	public function setTel($tel) {
		$this->tel = $tel;
	}

	public function setMail($mail) {
		$this->mail = $mail;
	}

	public function setAdresseNum($adresseNum) {
		$this->adresseNum = $adresseNum;
	}

	public function setAdresseVoie($adresseVoie) {
		$this->adresseVoie = $adresseVoie;
	}

	public function setadresseCp($adresseCp) {
		$this->adresseCp = $adresseCp;
	}

	public function setAdresseVille($adresseVille) {
		$this->adresseVille = $adresseVille;
	}

	public function setCarteId($carteId) {
		$this->carteId = $carteId;
	}

	public function setLogin($login) {
		$this->login = $login;
	}

	public function setMdp($mdp) {
		$this->mot_passe = $mdp;
	}

	public function setIdProfil($profil) {
		$this->id_profil = $profil;
	}

	public function inscription() {
		$oMyPdo = new MyPDO();
		$sSql = "INSERT INTO utilisateur (nom, prenom, tel, mail, adresseNum, adresseVoie, adresseCp, adresseVille) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		$oMyPdoStmt = $oMyPdo->prepare($sSql);
		$oMyPdoStmt->bindParam(1, $this->nom);
		$oMyPdoStmt->bindParam(2, $this->prenom);
		$oMyPdoStmt->bindParam(3, $this->tel);
		$oMyPdoStmt->bindParam(4, $this->mail);
		$oMyPdoStmt->bindParam(5, $this->adresseNum);
		$oMyPdoStmt->bindParam(6, $this->adresseVoie);
		$oMyPdoStmt->bindParam(7, $this->adresseCp);
		$oMyPdoStmt->bindParam(8, $this->adresseVille);
		return $oMyPdoStmt->execute();

	}

	public function inscription2($nom) {
		$oMyPdo = new MyPDO();
		$sSql = "SELECT id, nom FROM utilisateur WHERE nom='".$nom."' ORDER BY id DESC";
		$oPdoStmt = $oMyPdo->prepare($sSql);
		$oPdoStmt->execute();
		$result = $oPdoStmt->fetch(); 
		$this->id=$result[0];

		$sSql3 = "INSERT INTO lier (id_utilisateur_fk, id_profil_fk, login, mot_passe) VALUES (?, ?, ?, ?)";
		$a=1;
		$oMyPdoStmt3 = $oMyPdo->prepare($sSql3);
		$oMyPdoStmt3->bindParam(1, $this->id);
		$oMyPdoStmt3->bindParam(2, $a);
		$oMyPdoStmt3->bindParam(3, $this->login);
		$oMyPdoStmt3->bindParam(4, $this->mot_passe);
		return $oMyPdoStmt3->execute();

	}

	public function connexion($login, $mot_passe) {
		$oMyPdo = new MyPDO();
		$SqlTest = "SELECT id_utilisateur_fk, id_profil_fk, login, mot_passe FROM lier WHERE login='".$login."'";
        $oPdoStmt = $oMyPdo->prepare($SqlTest);
		$oPdoStmt->execute();
		$result = $oPdoStmt->fetch();
		if ($result==false){
            return 1;
        }
        if ($result[3]!=$mot_passe){
            return 2;
        }
        $this->login=$login;
        $this->mot_passe=$mot_passe;
        $this->id=$result[0];
        $this->id_profil=$result[1];
        
		
		$sSql = "SELECT * FROM utilisateur WHERE id='".$result[0]."'";
		$oPdoStmt2 = $oMyPdo->prepare($sSql);
		$oPdoStmt2->execute();
		$result2 = $oPdoStmt2->fetch(); 
		$this->nom=$result2[1];
		$this->prenom=$result2[2];
		$this->tel=$result2[3];
		$this->mail=$result2[4];
		$this->adresseNum = $result2[5];
		$this->adresseVoie = $result2[6];
		$this->adresseCp = $result2[7];
		$this->adresseVille = $result2[8];
		$this->carteId = $result2[9];
		$oPdoStmt2->execute();
		return 3;
	}

	public static function readAll() {
		$oPdo = new MyPDO();
		$sSql = "SELECT utilisateur.id,utilisateur.nom, utilisateur.prenom, utilisateur.tel, utilisateur.mail, utilisateur.adresseNum, utilisateur.adresseVoie, utilisateur.adresseCp, utilisateur.adresseVille, utilisateur.carteId, lier.login, lier.mot_passe FROM utilisateur INNER JOIN lier ON utilisateur.id=lier.id_utilisateur_fk ";
		$oPdoStmt = $oPdo->query($sSql);
		$autilisateur = $oPdoStmt->fetchAll(PDO::FETCH_CLASS, __CLASS__);	
		return $autilisateur;	
	}

	public function update() {
		$oMyPdo = new MyPDO();
		$sSql = "UPDATE utilisateur SET nom=:nouvNom, prenom=:nouvPrenom,  adresseNum=:nouvAdresseNum, adresseVoie=:nouvAdresseVoie, adresseCp=:nouvAdresseCp, adresseVille=:nouvAdresseVille, mail=:nouvMail, tel=:nouvTel WHERE id=".$this->id;
		$oMyPdoStmt = $oMyPdo->prepare($sSql);
		$nom = $this->nom;
		$prenom = $this->prenom;
		$tel = $this->tel;
		$mail = $this->mail;
		$adresseNum = $this->adresseNum;
		$adresseVoie = $this->adresseVoie;
		$adresseCp = $this->adresseCp;
		$adresseVille = $this->adresseVille;
		$login = $this->login;
		$mot_passe = $this->mot_passe;
		$id_profil = $this->id_profil;

		$oMyPdoStmt->execute(array('nouvNom' => $nom,'nouvPrenom' => $prenom, 'nouvAdresseNum' => $adresseNum, 'nouvAdresseVoie' => $adresseVoie, 'nouvAdresseCp' => $adresseCp, 'nouvAdresseVille' => $adresseVille, 'nouvMail' => $mail, 'nouvTel' => $tel  ));
		$sSql = "UPDATE lier SET id_profil_fk=:nouvIdProfil, login=:nouvLogin, mot_passe=:nouvMot_passe  WHERE id_utilisateur_fk=".$this->id;
		$oMyPdoStmt = $oMyPdo->prepare($sSql);
		$oMyPdoStmt->execute(array('nouvIdProfil' => $id_profil, 'nouvLogin' => $login,'nouvMot_passe' => $mot_passe  ));
		return true;

	}

	public function delete() {
		$oMyPdo = new MyPDO();
		$sSql = 'DELETE FROM lier WHERE id_utilisateur_fk=?';
		$oMyPdoStmt = $oMyPdo->prepare($sSql);
		$oMyPdoStmt->bindParam(1, $this->id);
		$oMyPdoStmt->execute();
		$sSql = 'DELETE FROM utilisateur WHERE id=?';
		$oMyPdoStmt = $oMyPdo->prepare($sSql);
		$oMyPdoStmt->bindParam(1, $this->id);
		return $oMyPdoStmt->execute();
	}

}

?>