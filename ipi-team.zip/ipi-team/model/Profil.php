<?php  

require 'config/MyPDO.php';

class Profil{
	private $id;
	private $type;

	public function __construct($id = null) {

		if (isset($id)) {
			$bd = new MyPDO();
			$sql = "SELECT * FROM profil WHERE id =".$id;
			$rqt= $bd->query($sql);
			$result = $rqt->fetch();

			$this->id = $result['id'];
			$this->titre = $result['type'];
		}
	}
	
	public function getId() {
		return $this->id;
	}

	public function getType() {
		return $this->type;
	}

////////////////////////////////////////////////////

	public function setId($id) {
		$this->id = $id;
	}

	public function setType($type) {
		$this->type = $type;
	}

}



?>