<?php 
require '../../config/MyPDO.php';


class Media{
	private $id;
	private $type;
	private $id_utilisateur_fk;

	public function __construct($id = null) {

		if (isset($id)) {
			$bd = new MyPDO();
			$sql = "SELECT * FROM media WHERE id =".$id;
			$rqt= $bd->query($sql);
			$result = $rqt->fetch();

			$this->id = $result['id'];
			$this->type = $result['type'];
			$this->id_utilisateur_fk = $result['id_utilisateur_fk'];
		}
	}
	
	public function getId() {
		return $this->id;
	}

	public function getType() {
		return $this->type;
	}

	public function getIdUtilisateur() {
		return $this->type;
	}

////////////////////////////////////////////////////

	public function setId($id) {
		$this->id = $id;
	}

	public function setType($type) {
		$this->type = $type;
	}

	public function setIdUtilisateur($id_utilisateur_fk) {
		$this->id_utilisateur_fk = $id_utilisateur_fk;
	}

	public function createMedia() {
		$oMyPdo = new MyPDO();
		$sSql = "INSERT INTO media (type, id_utilisateur_fk) VALUES (?, ?)";
		$oMyPdoStmt = $oMyPdo->prepare($sSql);
		$oMyPdoStmt->bindParam(1, $this->type);
		$oMyPdoStmt->bindParam(2, $this->id_utilisateur_fk);
		return $oMyPdoStmt->execute();
	}
}


 ?>