<?php
require '../../config/MyPDO.php';

class Image{
	private $id;
	private $nom;
	private $taille;
	private $type;
	private $descriptif;
	private $blob;


	public function __construct($id = null) {

		if (isset($id)) {
			$oMyPdo = new MyPDO();
			$sql = "SELECT * FROM image WHERE id =".$id;
			$oMyPdoStmt = $oMyPdo->prepare($sql);
			$oMyPdoStmt->execute();
			$result = $oMyPdoStmt->fetch();

			$this->id = $result[0];
			$this->nom = $result[1];
			$this->taille = $result[2];
			$this->type = $result[3];
			$this->descriptif = $result[4];
			$this->blob = $result[5];
		}
	}
	
	public function getId() {
		return $this->id;
	}

	public function getNom() {
		return $this->nom;
	}

	public function getTaille() {
		return $this->taille;
	}

	public function getType() {
		return $this->type;
	}

	public function getDescriptif() {
		return $this->descriptif;
	}

	public function getBlob() {
		return $this->blob;
	}

////////////////////////////////////////////////////

	public function setId($id) {
		$this->id = $id;
	}

	public function setNom($nom) {
		$this->nom = $nom;
	}

	public function setTaille($taille) {
		$this->taille = $taille;
	}

	public function setType($type) {
		$this->type = $type;
	}

	public function setDescriptif($descriptif) {
		$this->descriptif = $descriptif;
	}

	public function setBlob($blob) {
		$this->blob = $blob;
	}

	public function createImage() {
		$oMyPdo = new MyPDO();
		$sSql = "INSERT INTO image (nom, taille, type, descriptif, blob) VALUES (?, ?, ?, ?, ?)";
		$oMyPdoStmt = $oMyPdo->prepare($sSql);
		$oMyPdoStmt->bindParam(1, $this->nom);
		$oMyPdoStmt->bindParam(2, $this->taille);
		$oMyPdoStmt->bindParam(3, $this->type);
		$oMyPdoStmt->bindParam(4, $this->descriptif);
		$oMyPdoStmt->bindParam(5, $this->blob);
		return $oMyPdoStmt->execute();
	}

}



  ?>