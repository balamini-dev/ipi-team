-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  ven. 30 nov. 2018 à 08:48
-- Version du serveur :  5.7.23
-- Version de PHP :  7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ipi-team`
--

-- --------------------------------------------------------

--
-- Structure de la table `actualites`
--

DROP TABLE IF EXISTS `actualites`;
CREATE TABLE IF NOT EXISTS `actualites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(150) NOT NULL,
  `description` varchar(10000) NOT NULL,
  `date` date NOT NULL,
  `id_utilisateur_fk` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign key2` (`id_utilisateur_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `actualites`
--

INSERT INTO `actualites` (`id`, `titre`, `description`, `date`, `id_utilisateur_fk`) VALUES
(1, 'Coup de boule de Zizou', 'Le coup de tÃªte de Zidane est un incident qui s\'est dÃ©roulÃ© le 9 juillet 2006, lors de la finale de la coupe du monde de football Ã  Berlin, opposant la France Ã  l\'Italie. ZinÃ©dine Zidane, capitaine de l\'Ã©quipe de France et disputant son dernier match en tant que professionnel, assÃ¨ne lors des prolongations (alors que les deux Ã©quipes sont Ã  Ã©galitÃ© 1-1) un coup de tÃªte au thorax d\'un joueur de l\'Ã©quipe adverse, Marco Materazzi. D\'abord passÃ©e inaperÃ§ue aux yeux de l\'arbitre, la faute de Zidane lui vaut une expulsion sur carton rouge Ã  la 107Ã¨me minute de la rencontre, lorsqu\'elle est signalÃ©e. La France continue Ã  dix et perd cette finale aux tirs au but 5-3.  La teneur des propos du joueur italien a alimentÃ© de nombreuses spÃ©culations par diffÃ©rents journaux tels que la BBC, The Guardian, The Sun selon lesquels Materazzi aurait traitÃ© Zidane de Â« fils de putain terroriste Â», ce que Materazzi a niÃ© en bloc1.  Ce n\'est qu\'un an aprÃ¨s les faits que Marco Materazzi lui-mÃªme a livrÃ© sa propre version des propos Ã©changÃ©s. Zidane lui ayant dit Â« Si tu veux vraiment mon maillot, je te le donne aprÃ¨s le match Â» (Materazzi tirait sur son maillot), Materazzi lui aurait rÃ©pondu Â« Je prÃ©fÃ¨re ta putain de sÅ“ur Â».  MÃ©diatisÃ©, ce coup de tÃªte a donnÃ© lieu a de nombreuses interrogations en France sur les motifs de l\'acte. Une enquÃªte a Ã©tÃ© entamÃ©e par la FÃ©dÃ©ration internationale de football association (FIFA) sur ce sujet. La mÃ©diatisation a aussi donnÃ© lieu Ã  de nombreuses parodies, et le geste de Zidane a Ã©tÃ© l\'objet d\'une sculpture de bronze d\'Adel Abdessemed exposÃ©e Ã  Beaubourg en 2012.', '2006-07-09', 35),
(2, 'Un truc de footeux', 'Perso j\'aime pas le foot !', '2018-11-29', 35),
(3, 'Actu numÃ©ro 3', 'PurÃ©e vous en voulez encore ? ', '2018-11-29', 35),
(4, 'actu4', 'auj', '2018-11-29', 35),
(5, 'article 5', 'un tst', '2018-11-30', 35);

-- --------------------------------------------------------

--
-- Structure de la table `don`
--

DROP TABLE IF EXISTS `don`;
CREATE TABLE IF NOT EXISTS `don` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_utilisateur_fk` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_key_don` (`id_utilisateur_fk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `evenement`
--

DROP TABLE IF EXISTS `evenement`;
CREATE TABLE IF NOT EXISTS `evenement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(30) NOT NULL,
  `lieu` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `descriptif` varchar(100) NOT NULL,
  `type` varchar(10) NOT NULL,
  `id_utilisateur_fk` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign key` (`id_utilisateur_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `evenement`
--

INSERT INTO `evenement` (`id`, `titre`, `lieu`, `date`, `descriptif`, `type`, `id_utilisateur_fk`) VALUES
(3, 'Tous Ã  CGI', 'CGI', '2018-12-03', 'Je dois y Ãªtre Ã  14h, trop cool !', 'Collectif', 35),
(4, 'Evenement 2', 'ecole', '2018-11-29', 'today', 'sportif', 35),
(5, 'event 3', 'ici', '2018-12-12', 'bof', 'collectif', 35);

-- --------------------------------------------------------

--
-- Structure de la table `lier`
--

DROP TABLE IF EXISTS `lier`;
CREATE TABLE IF NOT EXISTS `lier` (
  `id_utilisateur_fk` int(11) NOT NULL,
  `id_profil_fk` int(11) NOT NULL,
  `login` varchar(20) NOT NULL,
  `mot_passe` varchar(20) NOT NULL,
  PRIMARY KEY (`id_utilisateur_fk`,`id_profil_fk`),
  KEY `foreign_key_lier2` (`id_profil_fk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `lier`
--

INSERT INTO `lier` (`id_utilisateur_fk`, `id_profil_fk`, `login`, `mot_passe`) VALUES
(1, 1, 'bala', 'mini'),
(35, 3, 'gaga', 'ryry'),
(37, 2, 'fofo', 'dede');

-- --------------------------------------------------------

--
-- Structure de la table `media`
--

DROP TABLE IF EXISTS `media`;
CREATE TABLE IF NOT EXISTS `media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(30) NOT NULL,
  `id_utilisateur_fk` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_key_media` (`id_utilisateur_fk`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `media`
--

INSERT INTO `media` (`id`, `type`, `id_utilisateur_fk`) VALUES
(1, 'video', 1),
(2, 'd', 1);

-- --------------------------------------------------------

--
-- Structure de la table `profil`
--

DROP TABLE IF EXISTS `profil`;
CREATE TABLE IF NOT EXISTS `profil` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `profil`
--

INSERT INTO `profil` (`id`, `type`) VALUES
(1, 'utilisateur'),
(2, 'editeur'),
(3, 'administrateur');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(140) NOT NULL,
  `prenom` varchar(140) NOT NULL,
  `adresseNum` int(200) NOT NULL,
  `adresseVoie` varchar(200) NOT NULL,
  `adresseCp` varchar(5) NOT NULL,
  `adresseVille` varchar(140) NOT NULL,
  `mail` varchar(200) NOT NULL,
  `tel` int(11) NOT NULL,
  `carteId` int(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `nom`, `prenom`, `adresseNum`, `adresseVoie`, `adresseCp`, `adresseVille`, `mail`, `tel`, `carteId`) VALUES
(1, 'diaby', 'balamini', 25, 'paul langevin', '93240', 'stains', 'bala@gmail.com', 698523578, NULL),
(35, 'Azenkout', 'Garry', 23, 'rue machin', '14000', 'Caen', 'hiro.nakamura@wanadoo.com', 3265418, NULL),
(37, 'Tandiang', 'Fode', 3, 'rue Super', '12346', 'Caen', 'fode.tandiang@gmail.com', 1234556789, NULL);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `actualites`
--
ALTER TABLE `actualites`
  ADD CONSTRAINT `foreign key2` FOREIGN KEY (`id_utilisateur_fk`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `don`
--
ALTER TABLE `don`
  ADD CONSTRAINT `foreign_key_don` FOREIGN KEY (`id_utilisateur_fk`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `evenement`
--
ALTER TABLE `evenement`
  ADD CONSTRAINT `foreign key` FOREIGN KEY (`id_utilisateur_fk`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `lier`
--
ALTER TABLE `lier`
  ADD CONSTRAINT `foreign_key_lier1` FOREIGN KEY (`id_utilisateur_fk`) REFERENCES `utilisateur` (`id`),
  ADD CONSTRAINT `foreign_key_lier2` FOREIGN KEY (`id_profil_fk`) REFERENCES `profil` (`id`);

--
-- Contraintes pour la table `media`
--
ALTER TABLE `media`
  ADD CONSTRAINT `foreign_key_media` FOREIGN KEY (`id_utilisateur_fk`) REFERENCES `utilisateur` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
