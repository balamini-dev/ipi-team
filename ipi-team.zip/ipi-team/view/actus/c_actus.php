<?php
session_start();
require '../../model/Actualite.php';
$actualites = Actualite::readAll();
require 'v_actus.php';
?>