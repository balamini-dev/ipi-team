<?php
session_start();
require '../../model/Actualite.php';

$bSuccess = false;
if(!empty($_POST)) {
	$actualite = new Actualite();

    $actualite->setTitre($_POST['titre']);
    $actualite->setDescription($_POST['description']);
    $actualite->setDate($_POST['date']);
    $actualite->setIdUtilisateur($_SESSION['id']);
    $bSuccess = $actualite->createActualite();
}
require 'v_createActu.php';

?>