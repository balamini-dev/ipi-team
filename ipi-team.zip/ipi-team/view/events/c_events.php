<?php
session_start();
require '../../model/Evenement.php';
$evenements = Evenement::readAll();
require 'v_events.php';
?>