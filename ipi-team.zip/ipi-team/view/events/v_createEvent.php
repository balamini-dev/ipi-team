<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<?php if ($bSuccess) :?>
    <div class="alert alert-success" role="alert">
    Votre enregistrement est terminé!
    </div>
<?php endif;?>
<div class="container">
  <h2>Ajouter un événement</h2>
  <form class="form-horizontal" method="post" action="c_createEvent.php">
    <div class="form-group">
      <label class="control-label col-sm-2" for="titre">Titre:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="titre" placeholder="titre" name="titre">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="titre">Lieu:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="lieu" placeholder="lieu" name="lieu">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="tel">Date:</label>
      <div class="col-sm-10">
        <input type="date" class="form-control" id="tel" placeholder="date" name="date">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="descriptif">Descriptif:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="descriptif" placeholder="Votre descriptif" name="descriptif">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="type">Type:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="type" placeholder="Votre descriptif" name="type">
      </div>
    </div>
    
    

    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-primary">Ajouter événement</button> <a href='c_events.php' class="btn btn-primary">Retour</a>
      </div>
    </div>
  </form>
</div>

</body>
</html>