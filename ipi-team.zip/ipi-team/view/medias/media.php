<?php

require '../../model/Media.php';

$bSuccess = false;
if(!empty($_POST)) {
	$media = new Media();

    $media->setType($_POST['type']);
    $media->setIdUtilisateur(1);

    $bSuccess = $media->createMedia();
   var_dump($media);
}


require 'formulaireMedia.php';

?>