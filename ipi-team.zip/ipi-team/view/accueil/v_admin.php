<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>
<h1>Liste des utilisateurs</h1>
<table class="table row-fluid col-12">
    <thead class="thead-dark">
        <tr>
            <th>Id</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>tel</th>
            <th>Mail</th>
            <th>Adresse</th>
            <th></th>
            <th></th>
            <th></th>
            <th>CarteId</th>
            <th>Login</th>
            <th>Mot de passe</th>
            <th></th>
            <th></th>
            
        </tr>
    </thead>
    <tbody>
    <?php foreach($autilisateur as $utilisateur) : ?>
        <tr>
            <td><?=$utilisateur->getId()?></td>
            <td><?=$utilisateur->getNom()?></td>
            <td><?=$utilisateur->getPrenom()?></td>
            <td><?=$utilisateur->getTel()?></td>
            <td><?=$utilisateur->getMail()?></td>
            <td><?=$utilisateur->getAdresseNum()?></td>
            <td><?=$utilisateur->getAdresseVoie()?></td>
            <td><?=$utilisateur->getAdresseCp()?></td>
            <td><?=$utilisateur->getAdresseVille()?></td>
            <td><?=$utilisateur->getCarteId()?></td>
            <td><?=$utilisateur->getLogin()?></td>
            <td><?=$utilisateur->getMdp()?></td>
            <td><a href="c_update.php?id=<?=$utilisateur->getId()?>" class="btn btn-warning">Modifier</a>
            <td><a href="c_delete.php?id=<?=$utilisateur->getId()?>" class="btn btn-danger">Supprimer</a>
        </tr>
    </tbody>
<?php endforeach; ?>
</table>
<div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <a href='../accueil/c_accueil.php' class="btn btn-primary">Retour</a>
      </div>
    </div>
</body>
</html>