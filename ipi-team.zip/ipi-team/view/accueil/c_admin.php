<?php
require '../../model/Utilisateur.php';

$autilisateur = Utilisateur::readAll();

require 'v_admin.php';
?>