<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Index</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/heroic-features.css" rel="stylesheet">

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="../accueil/c_accueil.php">ACCUEIL</a> 
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="#">A propos de nous</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Règlementation</a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="#">Faire un don</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Contact</a>
            </li>
              <?php if (isset($_SESSION['connexion'])) :?>

                  <?php if ($_SESSION['connexion']!=3) :?>
                      <li class="nav-item">
                          <a class="nav-link" href="../accueil/c_connexion.php">Se connecter</a>
                      </li>
                  <?php endif;?>

                  <?php if ($_SESSION['connexion']==3) :?>
                      <?php if (isset($_SESSION['profil']) AND $_SESSION['profil']==3) :?>
                          <li class="nav-item">
                              <a class="nav-link" href="c_admin.php">Gestion des utilisateurs</a>
                          </li>
                      <?php endif;?>
                      <li class="nav-item">
                          <a class="nav-link" href="c_monCompte.php?id=$_SESSION['id']">Mon compte</a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="../accueil/c_deconnexion.php">Deconnexion</a>
                      </li>
                      
                  <?php endif;?>

              <?php endif;?>
              <?php if (isset($_SESSION['connexion'])==false) :?>
                      <li class="nav-item">
                          <a class="nav-link" href="../accueil/c_connexion.php">Se connecter</a>
                      </li>
              <?php endif;?>
           
          </ul>
        </div>
      </div>
    </nav>

    <!-- Page Content -->
    <div class="container">

      <!-- Jumbotron Header -->
      <header class="jumbotron my-4">
        <h1 class="display-3">Bienvenue sur le site de l'IPI-TEAM</h1>
        <p class="lead">L’association « IPI-Team » est un groupe sportif qui rassemble une communauté de participants, notamment des personnes physiques ou morales pour supporter le club de foot de l’IPI.</p>
        <a href="c_inscription.php" class="btn btn-primary btn-lg">Pas encore inscrit ? Rejoignez-nous !</a>
      </header>

      <!-- Page Features -->
      <div class="row text-center">

        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card">
            <img src="images/actu.jpg" alt="" height="150" width="253">
            <div class="card-body">
              <h4 class="card-title">Actualité</h4>
              <p class="card-text">Suivre toutes les dernières actus dans l'association.</p>
            </div>
            <div class="card-footer">
              <a href="../actus/c_actus.php" class="btn btn-primary">En savoir plus</a>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card">
            <img src="images/events.jpg" alt="" height="150" width="253">
            <div class="card-body">
              <h4 class="card-title">Evénements</h4>
              <p class="card-text">Venez voir, ici, quels sont les événements (psportifs ou collectifs) organisés près de chez vous afin de rencontrer d'autres membres passionnés !</p>
            </div>
            <div class="card-footer">
              <a href="../events/c_events.php" class="btn btn-primary">En savoir plus</a>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card">
            <img src="images/medias.jpg" alt="" height="150" width="253">
            <div class="card-body">
              <h4 class="card-title">Médias</h4>
              <p class="card-text">Photos et vidéos d'événements passés.</p>
            </div>
            <div class="card-footer">
              <a href="../medias/c_medias.php" class="btn btn-primary">En savoir plus</a>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card">
            <img src="images/discussion.jpg" alt="" height="150" width="253">
            <div class="card-body">
              <h4 class="card-title">Discussion</h4>
              <p class="card-text">Difficile de se déplacer loin de chez vous ? Vous pouvez toujours dialoguer en ligne avec les autres membres !</p>
            </div>
            <div class="card-footer">
              <a href="#" class="btn btn-primary">En savoir plus</a>
            </div>
          </div>
        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">IPI-TEAM 2018</p>
        <p class="m-0 text-center text-white">Partenaires : </p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
