<?php
session_start();
require '../../model/Utilisateur.php';
$utilisateur = new Utilisateur ($_GET['id']);

if (isset($_POST['test'])){
	if($_POST['test']==1){
		$bSuccess = $utilisateur->delete();
		header('Location: http://localhost/exercices/ipi-team/view/accueil/c_admin.php');
		exit();
	}

	if($_POST['test']==2){
		header('Location: http://localhost/exercices/ipi-team/view/accueil/c_admin.php');
		exit();
	}
}



require 'v_delete.php';

?>