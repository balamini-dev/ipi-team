<?php
require '../../model/Utilisateur.php';

$bSuccess = false;
if(!empty($_POST)) {
	$utilisateur = new Utilisateur();


    $utilisateur->setNom($_POST['nom']);
    $utilisateur->setPrenom($_POST['prenom']);
    $utilisateur->setTel($_POST['tel']);
    $utilisateur->setMail($_POST['mail']); 
    $utilisateur->setAdresseNum($_POST['adresseNum']);
    $utilisateur->setAdresseVoie($_POST['adresseVoie']);
    $utilisateur->setAdresseCP($_POST['adresseCp']);
    $utilisateur->setAdresseVille($_POST['adresseVille']); 
	$utilisateur->setLogin($_POST['login']); 
    $utilisateur->setMdp($_POST['mdp']);

    $bSuccess = $utilisateur->inscription();
    $utilisateur->inscription2($_POST['nom']);
   
}
require 'v_inscription.php';

?>