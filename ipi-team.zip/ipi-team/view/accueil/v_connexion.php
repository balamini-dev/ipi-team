<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<?php if ($_SESSION['connexion']==1) :?>
    <div class="alert alert-success" role="alert">
      Votre pseudo n'existe pas. Peut-être n'êtes-vous pas encore inscrit ?
      <a href='c_inscription.php' class="btn btn-primary">S'inscrire</a>
    </div>
<?php endif;?>
<?php if ($_SESSION['connexion']==2) :?>
    <div class="alert alert-success" role="alert">
      Mot de passe incorrect.
    </div>
<?php endif;?>
<?php if ($_SESSION['connexion']==3) :?>
    <div class="alert alert-success" role="alert">
      Authentification réussie !
    <?php
      header('Location: http://localhost/ipi-team/view/accueil/c_accueil.php');
      exit();
    ?>
    </div>
<?php endif;?>
<div class="container">
  <h2>Se connecter</h2>
  <form class="form-horizontal" method="POST" action="c_connexion.php">
    <div class="form-group">
      <label class="control-label col-sm-2" for="login">Pseudo:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" placeholder="Votre pseudo" name="login">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Mot de passe:</label>
      <div class="col-sm-10">          
        <input type="password" class="form-control" placeholder="Votre mot de passe" name="mdp">
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <div class="checkbox">
          <label><input type="checkbox" name="remember"> Remember me</label>
        </div>
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-primary">Se connecter</button> <a href='../accueil/c_accueil.php' class="btn btn-primary">Retour</a>
      </div>
    </div>
  </form>
</div>

</body>
</html>