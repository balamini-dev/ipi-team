<?php 
session_start();
require '../../model/Utilisateur.php';

$utilisateur = new Utilisateur($_SESSION['id']);
$bSuccess = 0;

if(!empty($_POST)) {
    $utilisateur->setNom($_POST['nom']);
    $utilisateur->setPrenom($_POST['prenom']);
    $utilisateur->setTel($_POST['tel']);
    $utilisateur->setMail($_POST['mail']);
    $utilisateur->setAdresseNum($_POST['adresseNum']);
    $utilisateur->setAdresseVoie($_POST['adresseVoie']);
    $utilisateur->setAdresseCp($_POST['adresseCp']);
    $utilisateur->setAdresseVille($_POST['adresseVille']);
    $utilisateur->setCarteId($_POST['carteId']);
    $utilisateur->setLogin($_POST['login']);
    $utilisateur->setMdp($_POST['mdp']);

    $bSuccess = $utilisateur->update();

}
require 'v_monCompte.php';

?>