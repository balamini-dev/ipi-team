<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>

    <h1>Modifier un utilisateur</h1>
    <?php if ($bSuccess) :?>
    <div class="alert alert-success" role="alert">
        Les infos de l'utilisateur ont été modifiées avec succès !
    </div>
    <?php endif;?>
    <form class='row-fluid col-4' action='c_update.php' method='POST'>
        <div class="form-group"><label>Id :</label><input type="number" name="id" class="form-control" value='<?php echo $utilisateur->getId() ?>' readonly="true" /></div>
        <div class="form-group"><label>Nom :</label><input type='text' name='nom' class="form-control" value='<?php echo $utilisateur->getNom() ?>' ></div>
        <div class="form-group"><label>Prenom :</label><input type='text' name='prenom' class="form-control" value='<?php echo $utilisateur->getPrenom() ?>'></div>
        <div class="form-group"><label>tel :</label><input type='text' name='tel' class="form-control" value='<?php echo $utilisateur->getTel() ?>'></div>
        <div class="form-group"><label>Mail:</label><input type='text' name='mail' class="form-control" value='<?php echo $utilisateur->getMail() ?>'></div>
        <div class="form-group"><label>AdresseNum :</label><input type='number' name='adresseNum' class="form-control" value='<?php echo $utilisateur->getAdresseNum() ?>'></div>
        <div class="form-group"><label>AdresseVoie :</label><input type='text' name='adresseVoie' class="form-control" value='<?php echo $utilisateur->getAdresseVoie() ?>'></div>
        <div class="form-group"><label>AdresseCp :</label><input type='number' name='adresseCp' class="form-control" value='<?php echo $utilisateur->getAdresseCp() ?>'></div>
        <div class="form-group"><label>AdresseVille :</label><input type='text' name='adresseVille' class="form-control" value='<?php echo $utilisateur->getAdresseVille() ?>'></div>
        <div class="form-group"><label>CarteId :</label><input type='text' name='carteId' class="form-control" value='<?php echo $utilisateur->getCarteId() ?>' readonly="true"></div>
        <div class="form-group"><label>Login :</label><input type='text' name='login' class="form-control" value='<?php echo $utilisateur->getLogin() ?>'></div>
        <div class="form-group"><label>Mdp :</label><input type='text' name='mdp' class="form-control" value='<?php echo $utilisateur->getMdp() ?>'></div>
        <div class="form-group"><select name='id_profil' class="custom-select custom-select-lg mb-3">
                <option selected >Niveau admin</option>
                <option value="1">Utilisateur</option>
                <option value="2">Editeur</option>
                <option value="3">Administrateur</option>
                                </select>
        </div>

        


        <button type="submit" class="btn btn-primary">Modifier employé</button>
        <a href='c_admin.php' class="btn btn-primary">Retour</a>
    </form>
</body>
</html>