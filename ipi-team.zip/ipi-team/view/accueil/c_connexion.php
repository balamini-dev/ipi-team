<?php
session_start();
require '../../model/Utilisateur.php';

$_SESSION['connexion'] = 0;
if(!empty($_POST)) {
	$utilisateur = new Utilisateur();

    $_SESSION['connexion'] = $utilisateur->connexion($_POST['login'], $_POST['mdp']);

}

if ($_SESSION['connexion']==3){
    $_SESSION['id']=$utilisateur->getId();
    $_SESSION['nom']=$utilisateur->getNom();
    $_SESSION['prenom']=$utilisateur->getPrenom();
    $_SESSION['adresseNum']=$utilisateur->getAdresseNum();
    $_SESSION['adresseVoie']=$utilisateur->getAdresseVoie();
    $_SESSION['adresseCP']=$utilisateur->getadresseCp();
    $_SESSION['adresseVille']=$utilisateur->getAdresseVille();
    $_SESSION['mail']=$utilisateur->getMail();
    $_SESSION['tel']=$utilisateur->getTel();
    $_SESSION['carteId']=$utilisateur->getCarteId();
    $_SESSION['login']=$utilisateur->getLogin();
    $_SESSION['mdp']=$utilisateur->getMdp();
    $_SESSION['profil']=$utilisateur->getIdProfil();
}

require 'v_connexion.php';

?>