<?php session_start();
require '../../model/Utilisateur.php';

$utilisateur = new Utilisateur();
$bSuccess = 0;
if(!empty($_GET)){
	$utilisateur = new Utilisateur($_GET['id']);
}

if(!empty($_POST)) {
	$utilisateur->setId($_POST['id']);
    $utilisateur->setNom($_POST['nom']);
    $utilisateur->setPrenom($_POST['prenom']);
    $utilisateur->setTel($_POST['tel']);
    $utilisateur->setMail($_POST['mail']);
    $utilisateur->setAdresseNum($_POST['adresseNum']);
    $utilisateur->setAdresseVoie($_POST['adresseVoie']);
    $utilisateur->setAdresseCp($_POST['adresseCp']);
    $utilisateur->setAdresseVille($_POST['adresseVille']);
    $utilisateur->setCarteId($_POST['carteId']);
    $utilisateur->setLogin($_POST['login']);
    $utilisateur->setMdp($_POST['mdp']);
    $utilisateur->setIdProfil($_POST['id_profil']);

    $bSuccess = $utilisateur->update();

}
require 'v_update.php';

?>