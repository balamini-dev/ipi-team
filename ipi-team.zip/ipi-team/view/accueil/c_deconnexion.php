<?php
session_start();
session_destroy();
header('Location: http://localhost/ipi-team/view/accueil/c_accueil.php');
exit();
$_SESSION['profil']=false;
?>