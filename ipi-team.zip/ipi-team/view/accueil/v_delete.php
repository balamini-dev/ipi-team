<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>
<h1>Etes-vous sûr ?</h1>
<form class='row-fluid col-4' action='c_delete.php?id=<?=$utilisateur->getId()?>' method='POST'>
<select name='test' class="custom-select custom-select-lg mb-3">
                <option selected >Etes-vous sûr ?</option>
                <option value="1">Oui</option>
                <option value="2">Non</option>
</select>
<button type="submit" class="btn btn-primary">Valider</button>
</form>

</body>
</html>