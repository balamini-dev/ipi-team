<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<?php if ($bSuccess) :?>
    <div class="alert alert-success" role="alert">
    Votre inscription est terminée !
    </div>
<?php endif;?>
<div class="container">
  <h2>Formulaire d'inscription</h2>
  <form class="form-horizontal" method="post" action="c_inscription.php">
    <div class="form-group">
      <label class="control-label col-sm-2" for="nom">Nom:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="nom" placeholder="Votre nom" name="nom">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Prénom:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="prenom" placeholder="Votre prénom" name="prenom">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="tel">Téléphone:</label>
      <div class="col-sm-10">
        <input type="tel" class="form-control" id="tel" placeholder="Votre numéro de téléphone" name="tel">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-10">
        <input type="email" class="form-control" id="email" placeholder="Votre email" name="mail">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="adresse">Adresse:</label>
      <div class="col-sm-10">
        <input type="number" class="form-control" id="Add_num" placeholder="numéro de rue" name="adresseNum">
        <input type="text" class="form-control" id="Add_rue" placeholder="rue" name="adresseVoie">
        <input type="number" class="form-control" id="Add_CP" placeholder="75000" name="adresseCp">
        <input type="text" class="form-control" id="Add_ville" placeholder="Ville" name="adresseVille">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="login">Pseudo:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="login" placeholder="Votre pseudo" name="login">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Mot de passe:</label>
      <div class="col-sm-10">          
        <input type="password" class="form-control" id="pwd" placeholder="Votre mot de passe" name="mdp">
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <div class="checkbox">
          <label><input type="checkbox" name="remember"> Remember me</label>
        </div>
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-primary">Terminer mon inscription</button> <a href='../accueil/c_accueil.php' class="btn btn-primary">Retour</a>
      </div>
    </div>
  </form>
</div>

</body>
</html>