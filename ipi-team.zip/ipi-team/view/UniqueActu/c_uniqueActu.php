<?php
session_start();
require '../../model/Actualite.php';
$actualite = new Actualite($_GET['idActu']);
require 'v_uniqueActu.php';
?>