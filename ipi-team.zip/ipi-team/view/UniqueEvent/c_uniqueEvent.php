<?php
session_start();
require '../../model/Evenement.php';
$evenement = new Evenement($_GET['idEvent']);
require 'v_uniqueEvent.php';
?>