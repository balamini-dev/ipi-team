<?php
require '../../model/Evenement.php';

$bSuccess = false;
if(!empty($_POST)) {
	$evenement = new Evenement();


    $evenement->setTitre($_POST['titre']);
    $evenement->setLieu($_POST['lieu']);
    $evenement->setDate($_POST['date']);
    $evenement->setDescriptif($_POST['descriptif']); 
    $evenement->setType($_POST['type']);
    $evenement->setIdUtilisateur(1);

    $bSuccess = $evenement->createEvenement();
   var_dump($evenement);
}


require 'formulaireEvenement.php';

?>